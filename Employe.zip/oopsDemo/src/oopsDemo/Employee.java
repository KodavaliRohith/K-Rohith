package oopsDemo;

public class Employee {
    private int empId;
    private String name;
    private String gender;
    private int age;
    private double salary;
    private String designation;
    private String insuranceScheme;

    public Employee(int empId, String name, String gender, int age, double salary, String designation) {
        this.empId = empId;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.salary = salary;
        this.designation = designation;
        this.insuranceScheme = assignInsuranceScheme();
    }

    private String assignInsuranceScheme() {
        if (salary > 5000 && salary < 20000 && designation.equalsIgnoreCase("System Associate")) {
            return "Scheme C";
        } else if (salary >= 20000 && salary < 40000 && designation.equalsIgnoreCase("Programmer")) {
            return "Scheme B";
        } else if (salary >= 40000 && designation.equalsIgnoreCase("Manager")) {
            return "Scheme A";
        } else if (salary < 5000 && designation.equalsIgnoreCase("Clerk")) {
            return "No Scheme";
        } else {
            return "No Scheme";
        }
    }

    public void setDetails(int empId, String name, String gender, int age, double salary, String designation) {
        this.empId = empId;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.salary = salary;
        this.designation = designation;
        this.insuranceScheme = assignInsuranceScheme();
    }

    public String getDetails() {
        return String.format("Id: %d\nName: %s\nGender: %s\nAge: %d\nSalary: %.2f\nDesignation: %s\nInsurance Scheme: %s",
                empId, name, gender, age, salary, designation, insuranceScheme);
    }

    public void displayDetails() {
        System.out.println(getDetails());
    }
}