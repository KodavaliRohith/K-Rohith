package oopsDemo;
import java.util.Scanner;
public class MedicalMain {

	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        try {
	            System.out.println("Enter Employee ID: ");
	            int empId = scanner.nextInt();

	            System.out.println("Enter Employee Name: ");
	            String name = scanner.next();

	            System.out.println("Enter Gender: ");
	            String gender = scanner.next();

	            System.out.println("Enter Age: ");
	            int age = scanner.nextInt();

	            System.out.println("Enter Salary: ");
	            double salary = scanner.nextDouble();

	            System.out.println("Enter Designation: ");
	            String designation = scanner.next();

	            Employee emp = new Employee(empId, name, gender, age, salary, designation);
	            emp.displayDetails();
	        } 
	        catch (Exception e) 
	        {
	            System.out.println("No scheme.");
	        } 
	        finally 
	        {
	            scanner.close();
	        }
      }
}


