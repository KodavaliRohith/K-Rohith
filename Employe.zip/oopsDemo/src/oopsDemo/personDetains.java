package oopsDemo;
import java.util.Scanner;
public class personDetains {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the details as per the user choice,(person details :)");
		System.out.println("First name: ");
		String firstName=sc.nextLine();
		System.out.println("Last name:");
		String lastName=sc.nextLine();
		System.out.println("Gender:");
		String gender=sc.nextLine();
		System.out.println("Age:");
		int age=sc.nextInt();
		System.out.println("weight:");
		double weight=sc.nextDouble();
		System.out.println("person details:");
		System.out.println("_____________________");
		
		System.out.println("First Name:" + firstName);
		System.out.println("Last Name: "+ lastName);
		System.out.println("Gender:"+ gender);
		System.out.println("Age:"+ age);
		System.out.println("Weight:"+ weight);
		sc.close();
		
				
		
		
	}

}
