package com.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class DateTest {

    @Test
    public void testConstructor() {
        Date date = new Date(10, 5, 2023);
        assertEquals(10, date.getDay());
        assertEquals(5, date.getMonth());
        assertEquals(2023, date.getYear());
    }

    @Test
    public void testSetDay() {
        Date date = new Date(1, 1, 2000);
        date.setDate(15);
        assertEquals(15, date.getDay());
    }

    @Test
    public void testGetDay() {
        Date date = new Date(25, 12, 2020);
        assertEquals(25, date.getDay());
    }

    @Test
    public void testSetMonth() {
        Date date = new Date(1, 1, 2000);
        date.setMonth(8);
        assertEquals(8, date.getMonth());
    }

    @Test
    public void testGetMonth() {
        Date date = new Date(25, 12, 2020);
        assertEquals(12, date.getMonth());
    }

    @Test
    public void testSetYear() {
        Date date = new Date(1, 1, 2000);
        date.setYear(2021);
        assertEquals(2021, date.getYear());
    }

    @Test
    public void testGetYear() {
        Date date = new Date(25, 12, 2020);
        assertEquals(2020, date.getYear());
    }

    @Test
    public void testToString() {
        Date date = new Date(31, 12, 2022);
        assertEquals("Date is 31/12/2022", date.toString());
        }
}