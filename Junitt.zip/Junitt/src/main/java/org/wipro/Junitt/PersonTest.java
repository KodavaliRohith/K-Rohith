package org.wipro.Junitt;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PersonTest {

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorThrowsExceptionForNullNames() {
        new Person(null, null);
    }

    @Test
    public void testGetFullNameBothNamesPresent() {
        Person person = new Person("John", "Doe");
        assertEquals("John Doe", person.getFullName());
    }

    @Test
    public void testGetFullNameFirstNameNull() {
        Person person = new Person(null, "Doe");
        assertEquals("? Doe", person.getFullName());
    }

    @Test
    public void testGetFullNameLastNameNull() {
        Person person = new Person("John", null);
        assertEquals("John ?", person.getFullName());
    }

    @Test
    public void testGetFirstName() {
        Person person = new Person("John", "Doe");
        assertEquals("John", person.getFirstName());
    }

    @Test
    public void testGetLastName() {
        Person person = new Person("John", "Doe");
        assertEquals("Doe", person.getLastName());
    }

    @Test
    public void testMain() {
        Person person = new Person("a", "b");
        assertEquals("a", person.getFirstName());
}
}