package com.wipro;

public class MainApp {

	public static void main(String[] args) {
		StringOperation so=(x)->
		{
			char[] ch=x.toCharArray();
			int i=0;int j=ch.length-1;
			while(i<j)
			{
				char c=ch[i];
				ch[i]=ch[j];
				ch[j]=c;
				i++;
				j--;
			}
			return new String(ch);
		};
		String result=applyoperation("welcome to", so);
		System.out.println(result);
	}
	private static String applyoperation(String s, StringOperation operation)
	{
		return operation.stringOperation(s);
	}
}
