package com.wipro;

public interface StringOperation {
	String stringOperation(String s);
}
