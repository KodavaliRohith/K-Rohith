package com.wipro1;

public interface ArthematicOperations {
	double operate(double a,double b);
}
