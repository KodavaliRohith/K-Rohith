package com.wipro1;

public class MainArthematicOp {

	public static void main(String[] args) {
	ArthematicOperations addition=(x,y)->x+y;
	ArthematicOperations substraction=(x,y)->x-y;
	ArthematicOperations multiplication=(x,y)->x*y;
	ArthematicOperations division=(x,y)->x/y;
	perfromOperation(2, 3, addition);
	perfromOperation(4,1,substraction);
	perfromOperation(2, 5, multiplication);
	perfromOperation(10, 5, division);
	

	};
	private static void perfromOperation(double a,double b,ArthematicOperations operations)
	{
		System.out.println(operations.operate(a, b));
	}
}
