package com.wipro2;

public interface Exponentiation {
  double power(double x, double y);
}
