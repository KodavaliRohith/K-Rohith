package com.wipro2;

import java.util.Scanner;

public class MainApp {

	public static void main(String[] args)
{
        StringTransform toUpperCase = s -> s.toUpperCase();
        System.out.println("Uppercase: " + toUpperCase.stringtransform("hello"));
        StringTransform reverseString = s -> new StringBuilder(s).reverse().toString();
        System.out.println("Reversed: " + reverseString.stringtransform("hello"));
        StringTest isPalindrome = s -> s.equalsIgnoreCase(new StringBuilder(s).reverse().toString());
        System.out.println("Is 'madam' a palindrome? " + isPalindrome.test("madam"));
        char specificChar = 'e';
        StringTest containsChar = s -> s.indexOf(specificChar) >= 0;
        System.out.println("Does 'hello' contain the character 'e'? " + containsChar.test("hello"));
        Exponentiation powerFunction = (x, y) -> Math.pow(x, y);
        System.out.println("2^3 = " + powerFunction.power(2, 3));
        System.out.println("Formatted string: " + formatStringWithSpaces("CG"));
        System.out.println("Authentication: " + authenticate("admin", "password"));
 }
    public static String formatStringWithSpaces(String input) 
    {
        StringTransform formatWithSpaces = s -> String.join(" ", s.split(""));
        return formatWithSpaces.stringtransform(input);
    }
    public static boolean authenticate(String username, String password)
    {
        StringTest auth = u -> u.equals("admin") && password.equals("password");
        return auth.test(username);
     }

}
