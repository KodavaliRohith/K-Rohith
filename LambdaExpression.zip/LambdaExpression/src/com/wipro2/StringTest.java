package com.wipro2;

public interface StringTest {
	Boolean test(String s);

	
}
