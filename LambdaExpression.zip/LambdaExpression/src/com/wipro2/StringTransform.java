package com.wipro2;
@FunctionalInterface
public interface StringTransform {
	String stringtransform(String s);

	
}
