package org.wipro3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EmployeeService {

    public double sumOfSalaries(List<Employee> employees) {
        return employees.stream()
                        .mapToDouble(Employee::getSalary)
                        .sum();
    }

    public Optional<Employee> findSeniorMostEmployee(List<Employee> employees) {
        return employees.stream()
                        .max(Comparator.comparing(Employee::getHireDate));
    }

    public void listEmployeeServiceDuration(List<Employee> employees) {
        employees.forEach(emp -> {
            LocalDate hireDate = emp.getHireDate();
            Period period = Period.between(hireDate, LocalDate.now());
            System.out.println(emp.getFirstName() + " " + emp.getLastName() + " - " +
                               period.getYears() + " years, " +
                               period.getMonths() + " months and " +
                               period.getDays() + " days");
        });
    }

    public List<Employee> findEmployeesWithoutDepartment(List<Employee> employees) {
        return employees.stream()
                        .filter(emp -> emp.getDepartment() == null || emp.getDepartment().isEmpty())
                        .collect(Collectors.toList());
    }

    public void listEmployeeStartDetails(List<Employee> employees) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd (EEE)");
        employees.forEach(emp -> {
            String hireDateStr = emp.getHireDate().format(formatter);
            System.out.println(emp.getFirstName() + " " + emp.getLastName() + " - Hired on " + hireDateStr);
        });
    }

    public void listEmployeeSalaryWithIncrease(List<Employee> employees) {
        employees.forEach(emp -> {
            double currentSalary = emp.getSalary();
            double increasedSalary = currentSalary * 1.15;
            System.out.println(emp.getFirstName() + " " + emp.getLastName() +
                               " - Current Salary: " + currentSalary +
                               ", Increased Salary: " + increasedSalary);
        });
    }

    public List<Employee> findEmployeesWithoutManager(List<Employee> employees) {
        return employees.stream()
                        .filter(emp -> emp.getManagerId() == 0)
                        .collect(Collectors.toList());
    }

    public void printDurationFromGivenDate(LocalDate startDate) {
        LocalDate currentDate = LocalDate.now();
        Period period = Period.between(startDate, currentDate);
        System.out.println("Duration: " + period.getYears() + " years, " +
                           period.getMonths() + " months, " +
                           period.getDays() + " days");
    }

    public void printDurationBetweenDates(LocalDate startDate, LocalDate endDate) {
        Period period = Period.between(startDate, endDate);
        System.out.println("Duration: " + period.getYears() + " years, " +
                           period.getMonths() + " months, " +
                           period.getDays() + " days");
    }

    public void printWarrantyExpirationDate(LocalDate purchaseDate, int months, int years) {
        LocalDate expirationDate = purchaseDate.plusMonths(months).plusYears(years);
        System.out.println("Warranty expires on: " + expirationDate);
    }
}