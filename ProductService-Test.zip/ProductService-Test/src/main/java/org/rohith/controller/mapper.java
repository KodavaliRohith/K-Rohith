package org.rohith.controller;

public interface mapper {

}
