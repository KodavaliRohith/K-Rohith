package org.rohith.service;

import java.util.List;

import org.rohith.entity.Product;

public interface ProductService {
	
	Product getById(int id);
	Product addProduct(Product product);
	Product updateProduct(int id,Product product);
	void deleteProduct(int id);
	List<Product> getAllProductt();
	List<Product> getAllProduct();
	List <Product> getByName(String name);
}
