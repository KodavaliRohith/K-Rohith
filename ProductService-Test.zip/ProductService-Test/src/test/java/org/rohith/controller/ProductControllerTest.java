package org.rohith.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.rohith.entity.Product;
import org.rohith.service.ProductService;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
@ExtendWith(MockitoExtension.class)
class ProductControllerTest {
	@Mock
	ProductService productService;
	@InjectMocks
	ProductController productController;
	
	MockMvc mockMvc;
	ObjectMapper mapper= new ObjectMapper();
	@BeforeEach
	public void setUp() {
		mockMvc=MockMvcBuilders.standaloneSetup(productController).build();
	}

	@Test
	void testGetAll() throws Exception {
		
		List<Product> productt=List.of(
				new Product(1,"Fridge",23000,2),
				new Product(2,"Cooler",1500,3),
				new Product(3,"AirCooler",2000,4)
				);
		when(productService.getAllProduct()).thenReturn(productt);
//		mockMvc.perform(get("/api/productt").accept(MediaType.APPLICATION_JSON_VALUE))
//         .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
//         .andExpect(status().isOk())
//         .andExpect(jsonPath("$").exists())
//         .andExpect(jsonPath("$.size()").value(3));
		    
            mockMvc.perform(get("/api/productt").accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$").exists())
            .andExpect(jsonPath("$.size()").value(3));
	}

	@Test
	void testGetById() throws Exception {
		int id=1;
		Product product =new Product(1,"AirBag",230,2);
		when(productService.getById(id)).thenReturn(product);
		
//		mockMvc.perform(get("/api/productt/{id}",id).accept(MediaType.APPLICATION_JSON_VALUE)
//				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
//        .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
//         .andExpect(status().isOk())
//         .andExpect(jsonPath("$.name").value("AirBag"));
		
		mockMvc.perform(get("/api/productt/{id}",id).accept(MediaType.APPLICATION_JSON_VALUE))
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
         .andExpect(status().isOk())
         .andExpect(jsonPath("$.name").value("AirBag"));
	
	}

	@Test
	void testAddProduct() throws  Exception{
		Product pro=new Product(8,"Watch",2000,3);
		String proJson=mapper.writeValueAsString(pro);
		when(productService.addProduct(any(Product.class))).thenReturn(pro);
		
	   
		
//		mockMvc.perform(post("/api/employees").content(proJson).contentType(MediaType.APPLICATION_JSON_VALUE)
//				.accept(MediaType.APPLICATION_JSON_VALUE))
//		.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
//		.andExpect(status().isCreated())
//		.andExpect(jsonPath("$").exists())
//		.andExpect(jsonPath("$.name", is("Watch")));
		
		mockMvc.perform(post("/api/productt").content(proJson).contentType(MediaType.APPLICATION_JSON_VALUE)
				.accept(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isCreated())
				.andExpect(jsonPath("$.name", is("Watch")));
		
		
	}

	@Test
	void testUpdateProduct() throws Exception {
		int id=2;
		Product original=new Product(2,"AirConditioner",2300,5);
		
		String proJson=mapper.writeValueAsString(original);
		when(productService.updateProduct(anyInt(),any(Product.class))).thenReturn(original);
		
		mockMvc.perform(put("/api/productt/{id}",id).content(proJson).contentType(MediaType.APPLICATION_JSON_VALUE)
				.accept(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk());
				
		
		
		
	}



	@Test
	void testDelete() throws Exception{
		int id=2;
		mockMvc.perform(delete("/api/productt/{id}",id))
		.andExpect(status().isNoContent());
		
	}

}
