package org.rohith.service;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.rohith.entity.Product;
import org.rohith.repository.ProductRepository;
@ExtendWith(MockitoExtension.class)
class ProductServiceImplTest {
	@Mock
	ProductRepository productRepository;
	@InjectMocks
	 ProductServiceImpl productServiceImpl;
		// TODO Auto-generated constructor stub

	@Test
	@Disabled
	void testProductServiceImpl() {
		fail("Not yet implemented");
	}

	@Test
	
	void testGetAllProduct() {
		
		List<Product> productt=List.of(new Product(4,"Mouse",300,4),
			new Product(5,"keyboard",2500,1));
		System.out.println(productt);
		when(productRepository.findAll()).thenReturn(List.of(new Product(4,"Mouse",300,4),new Product(5,"keyboard",2500,1)));
		
		
		List<Product> pros=productServiceImpl.getAllProduct();
		System.out.println(pros);
		assertAll(
				()-> assertEquals(2,pros.size()),
				()->assertEquals(pros.get(0).getName(), "Mouse")
				);
	}

	@Test
	
	void testGetById() {
		Product pro=new Product(14,"TV",5000,2);
		when(productRepository.findById(14)).thenReturn(Optional.of(pro));
		Product product=productServiceImpl.getById(14);
		
		assertAll(
				
				()->assertEquals(product.getId(),14),
				()->assertEquals(product.getName(), "TV"),
				()->assertEquals(pro, product)
				);
		
		
		
	}

	@Test
	
	void testAddProduct() {
		Product pro=new Product(5,"Cable",350,2);
		when(productRepository.save(pro)).thenReturn(pro);
		Product product=productServiceImpl.addProduct(pro);
		assertAll(
				()->assertEquals(product.getPrice(), 350),
				()->assertNotNull(product)
				);
	}

	@Test
	
	void testUpdateProduct() {
       Product pro=new Product(9,"IWatch",20000,2);
		
       Product product=new Product(9,null,23000,3);
		
		when(productRepository.findById(9)).thenReturn(Optional.of(pro));
		
		
        when(productRepository.save(any(Product.class))).thenReturn(pro);
		
		Product updatedEmployee=productServiceImpl.updateProduct(9, product);
		
		System.out.println(updatedEmployee);
		
		
		
		
		
		
		assertAll(
				()->assertEquals(updatedEmployee.getPrice(), 23000),
				()->assertEquals(updatedEmployee.getName(), "IWatch"),
				()->assertEquals(updatedEmployee.getId(), 9)
				
				
				);
		
	}

	@Test
	
	void testDeleteProduct() {
		Product pro=new Product(5,"cable",350,2);
		when(productRepository.findById(5)).thenReturn(Optional.of(pro));
		productServiceImpl.deleteProduct(5);
		verify(productRepository,times(1)).deleteById(5);
	}

	
	
	void testGetByName() {
		
		List <Product> productt=List.of(
				new Product(1,"AC",2500,2),
				new Product(2,"Fan",1000,12)
				);
		when(productRepository.findByName("AC")).thenReturn(productt);
		
		List<Product> pros=productServiceImpl.getByName("AC");
		assertAll(
				()->assertEquals(pros.size(),2),
				()->assertEquals(pros.get(1).getPrice(), 1000)
				);
				
	}

}
