package org.rohith.controller;

import java.util.List;

import org.rohith.dto.ProductDto;
import org.rohith.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/products")
@CrossOrigin
public class ProductController {
	@Autowired
	private ProductService productService;
	
	@GetMapping
	public ResponseEntity<List<ProductDto>> getAllProducts(){
		return ResponseEntity.ok(productService.getAllProducts());
		
	}
	@GetMapping("/{id}")
	public ResponseEntity<ProductDto> getProductById(@PathVariable int id){
		return ResponseEntity.ok(productService.getProductById(id));
	}
	@PostMapping
	public ResponseEntity<ProductDto> addProduct(@RequestBody ProductDto productDto) 
	{
		
		
		return new ResponseEntity<ProductDto>(productService.addProduct(productDto), HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<ProductDto> updateProduct(@PathVariable int id, @RequestBody ProductDto productDto) {
		//TODO: process PUT request
		
		return ResponseEntity.ok(productService.updateProduct(id, productDto ));
	}
	
	@DeleteMapping("/{id}")
	public void deleteProduct(@PathVariable int id) {
		productService.deleteProduct(id);
	}


}
