package org.rohith.service;

import java.util.List;

import org.rohith.dto.ProductDto;

public interface ProductService {
	
	List<ProductDto> getAllProducts();
	ProductDto getProductById(int id);
	ProductDto addProduct(ProductDto productDto);
	ProductDto updateProduct(int id,ProductDto productDto);
	void deleteProduct(int id);
	

}
