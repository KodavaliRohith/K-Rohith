package org.rohith.service;

import java.util.ArrayList;
import java.util.List;


import org.rohith.dto.ProductDto;
import org.rohith.entity.Product;
import org.rohith.repository.ProductRepository;
import org.springframework.stereotype.Service;


@Service
public class ProductServiceImpl implements ProductService {

	private ProductRepository productRepository;
	

	public ProductServiceImpl(ProductRepository productRepository) {
		
		this.productRepository = productRepository;
	}


	@Override
	public List<ProductDto> getAllProducts() {
		
		List<Product> products=productRepository.findAll();
		System.out.println("products:"+products);
		List<ProductDto> productDtos=new ArrayList<>();
		for (Product product : products) {
			ProductDto productDto = new ProductDto();
			productDto.setProductname(product.getProductname());
			productDto.setQuality(product.getQuality());
			productDto.setId(product.getId());
			productDtos.add(productDto);
		}
		
		return productDtos;

	}

	@Override
	public ProductDto getProductById(int id) {
		
		Product product=productRepository.findById(id).get();
		ProductDto productDto = new ProductDto();
		productDto.setProductname(product.getProductname());
		productDto.setQuality(product.getQuality());
		productDto.setId(product.getId());
		return productDto;

	}

	@Override
	public ProductDto addProduct(ProductDto productDto) {
		Product product=new Product();
		product.setProductname(productDto.getProductname());
		product.setQuality(productDto.getQuality());
		Product savedProduct= productRepository.save(product);
		ProductDto savedProductDto=new ProductDto();
		savedProductDto.setProductname(savedProduct.getProductname());
		savedProductDto.setQuality(savedProduct.getQuality());
		savedProductDto.setId(savedProduct.getId());
		return savedProductDto;

	}

	@Override
	public ProductDto updateProduct(int id, ProductDto productDto) {
		Product existingProduct=productRepository.findById(id).get();
		if (productDto.getProductname() != null)
			existingProduct.setProductname(productDto.getProductname());
		if (productDto.getQuality() != null)
			existingProduct.setQuality(productDto.getQuality());
		
		Product updatedProduct=productRepository.save(existingProduct);
		ProductDto updatedProductDto=new ProductDto();
		updatedProductDto.setProductname(updatedProduct.getProductname());
		updatedProductDto.setQuality(updatedProduct.getQuality());
		updatedProductDto.setId(updatedProduct.getId());
		return updatedProductDto;
		

	}

	@Override
	public void deleteProduct(int id) {
		productRepository.deleteById(id);


	}


}
