package org.rohith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductAppServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
