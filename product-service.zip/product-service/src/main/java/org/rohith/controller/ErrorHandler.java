package org.rohith.controller;


import org.rohith.exception.ProductNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ErrorHandler {
	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity <String> handleProductNotFound(ProductNotFoundException ex){
		return new ResponseEntity<String>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> handleValidationErrors(MethodArgumentNotValidException ex){
		StringBuilder errors=new StringBuilder();
		ex.getBindingResult().getAllErrors().forEach(err->{
			String e=err.getDefaultMessage();
			errors.append(e+"\n");
		});
	
	return new ResponseEntity<String>(errors.toString(),HttpStatus.BAD_REQUEST);
	}
}
