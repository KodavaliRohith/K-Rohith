package org.rohith.controller;

import java.util.List;

import org.rohith.entity.Product;
import org.rohith.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/productt")
public class ProductController {
	@Autowired
	private ProductService productService;
	@GetMapping
	public ResponseEntity< List<Product>> getAll(){
		List <Product> productt=productService.getAllProduct();
		return ResponseEntity.ok(productt);
	}
	@GetMapping("/{id}")
	public ResponseEntity<Product> getById(@PathVariable int id) {
		Product product=productService.getById(id);
		return new ResponseEntity <Product>(product,HttpStatus.OK);
		
	}
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Product addProduct(@Valid @RequestBody Product product) {
		return productService.addProduct(product);
	
		
		
	}
	@PutMapping("/{id}")
	public Product update(@PathVariable int id,@Valid @RequestBody Product product) {
		return productService.updateProduct(id, product);
		
	}
	@DeleteMapping("/{id}")
	public ResponseEntity delete(@PathVariable int id) {
		productService.deleteProduct(id);
		return ResponseEntity.noContent().build();
	}
	@GetMapping("/name/{name}")
	public List<Product> getMethodName(@PathVariable String name){
		return productService.getByName(name); 
	}
}
