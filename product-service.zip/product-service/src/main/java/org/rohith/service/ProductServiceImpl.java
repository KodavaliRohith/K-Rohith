package org.rohith.service;

import java.util.List;
import java.util.Optional;

import org.rohith.entity.Product;
import org.rohith.exception.ProductNotFoundException;
import org.rohith.repository.ProductRepository;
import org.springframework.stereotype.Service;
@Service
public class ProductServiceImpl implements ProductService {
	private ProductRepository productRepository;

	public ProductServiceImpl(ProductRepository productRepository)
	{
		this.productRepository=productRepository;
	}
	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getById(int id) {
		// TODO Auto-generated method stub
		return productRepository.findById(id)
				.orElseThrow(()-> new ProductNotFoundException("Product with Id "+id+" not found"));
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public Product updateProduct(int id, Product product) {
		Optional<Product> optPro=productRepository.findById(id);
		if(!optPro.isPresent()) {
			throw new ProductNotFoundException("Product with id "+id+" not found");
		}
		Product pro=optPro.get();
		if(product.getName()!=null) {
			pro.setName(product.getName());
		}
		
		if(product.getPrice()!=0) {
			pro.setPrice(product.getPrice());
		}
		if(product.getQuantity()!=0) {
			pro.setQuantity(product.getQuantity());
		}
		product.setId(id);
		return productRepository.save(pro);
		
	}

	@Override
	public void deleteProduct(int id) {
		Optional<Product> optpro=productRepository.findById(id);
		if(!optpro.isPresent()) {
			throw new ProductNotFoundException("Product with id "+id+" not found");
		}
		productRepository.deleteById(id);
	}
	@Override
	public List<Product> getAllProductt() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Product> getByName(String name){
		return productRepository.findByName(name);
	}
	
	

}
